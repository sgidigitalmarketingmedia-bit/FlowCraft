# Native iOS (SwiftUI)
Project: FinPulse Mobile - Banking & Crypto Flow
Target: iOS 18+ / iPhone 16 Pro
Framework: SwiftUI with Spring Navigation & State Management

### How to Run:
1. Open Xcode 16+.
2. Create a new iOS App project with SwiftUI interface.
3. Paste `ContentView.swift` into your project and press Run (Cmd+R).