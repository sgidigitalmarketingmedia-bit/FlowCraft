# Export to Figma (REST API & 1-Click Desktop Importer)
Project: FinPulse Mobile - Banking & Crypto Flow

### Method 1: 1-Click Desktop Figma Plugin Console
1. Open any Figma file in your browser or desktop app.
2. In Figma, navigate to: **Plugins -> Development -> Open Console** (or use the Scripter plugin).
3. Paste the contents of `figma-plugin-import.js` and press Run.
4. All 6 screens will automatically be generated as native auto-layout frames with correct dimensions, fills, and typography!

### Method 2: Figma REST API / Webhooks
Use `figma-rest-document.json` directly with the Figma REST API. It follows the official Figma Node hierarchy (DOCUMENT -> CANVAS -> FRAME -> ELEMENT) with complete prototype interaction links.
