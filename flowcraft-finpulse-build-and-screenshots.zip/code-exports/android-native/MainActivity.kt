package com.flowcraft.mobile.ui

/**
 * Android Native Jetpack Compose Architecture
 * Project: FinPulse Mobile - Banking & Crypto Flow
 * Target Platform: Android 15 (API 35) / Jetpack Compose BOM 2024.09+
 * Tested on: Google Pixel 9 Pro & Samsung Galaxy S25 / S24 Ultra
 */

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            FlowCraftAndroidTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Color(0xFF0F172A)
                ) {
                    AppNavigationGraph()
                }
            }
        }
    }
}

sealed class ScreenRoute(val route: String) {
    object MotionLaunchSplash : ScreenRoute("screen_splash")
    object WelcomeOnboarding : ScreenRoute("screen_onboarding")
    object BiometricSignIn : ScreenRoute("screen_auth")
    object MainPortfolioDashboard : ScreenRoute("screen_dashboard")
    object InstantTransferForm : ScreenRoute("screen_transfer")
    object TransferCompletedReceipt : ScreenRoute("screen_success")
}

@Composable
fun AppNavigationGraph() {
    val navController = rememberNavController()
    val startDestination = ScreenRoute.MotionLaunchSplash.route

    NavHost(
        navController = navController,
        startDestination = startDestination
    ) {
        composable(ScreenRoute.MotionLaunchSplash.route) {
            MotionLaunchSplashScreen(navController = navController)
        }
        composable(ScreenRoute.WelcomeOnboarding.route) {
            WelcomeOnboardingScreen(navController = navController)
        }
        composable(ScreenRoute.BiometricSignIn.route) {
            BiometricSignInScreen(navController = navController)
        }
        composable(ScreenRoute.MainPortfolioDashboard.route) {
            MainPortfolioDashboardScreen(navController = navController)
        }
        composable(ScreenRoute.InstantTransferForm.route) {
            InstantTransferFormScreen(navController = navController)
        }
        composable(ScreenRoute.TransferCompletedReceipt.route) {
            TransferCompletedReceiptScreen(navController = navController)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MotionLaunchSplashScreen(navController: NavController) {
    val scrollState = rememberScrollState()
    var inputValue by remember { mutableStateOf("") }
    var toggleState by remember { mutableStateOf(true) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("00. Motion Launch Splash", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    
                },
                actions = {
                    IconButton(onClick = { /* Handle Notifications */ }) {
                        Icon(Icons.Default.Notifications, contentDescription = "Notifications", tint = Color.LightGray)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF0F172A))
            )
        },
        containerColor = Color(0xFF0F172A)
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(scrollState)
                .padding(horizontal = 20.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text("FlowCraft Pro Launch Screen", color = Color.White)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WelcomeOnboardingScreen(navController: NavController) {
    val scrollState = rememberScrollState()
    var inputValue by remember { mutableStateOf("") }
    var toggleState by remember { mutableStateOf(true) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("01. Welcome Onboarding", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                },
                actions = {
                    IconButton(onClick = { /* Handle Notifications */ }) {
                        Icon(Icons.Default.Notifications, contentDescription = "Notifications", tint = Color.LightGray)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF0F172A))
            )
        },
        containerColor = Color(0xFF0F172A)
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(scrollState)
                .padding(horizontal = 20.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text("FinPulse Mobile", color = Color.White)
            // Card: Zero Fee Global Transfers
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B))
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Zero Fee Global Transfers", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    Text("Manage 42 fiat currencies and digital assets in one high-security mobile vault.", color = Color.Gray, fontSize = 12.sp)
                }
            }
            Text("Platform Architecture Walkthrough", color = Color.White)
            // Badge: SOC-2 Type II Verified & Bank-Grade Encrypted
            Surface(
                color = Color(0xFF10B981).copy(alpha = 0.15f),
                shape = RoundedCornerShape(20.dp)
            ) {
                Text(
                    text = "SOC-2 Type II Verified & Bank-Grade Encrypted",
                    color = Color(0xFF10B981),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                )
            }
            // Button: Get Started Now
            Button(
                onClick = {
                    navController.navigate("screen_auth")
                    
                },
                modifier = Modifier.fillMaxWidth().height(52.dp),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2563EB))
            ) {
                Text("Get Started Now", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color.White)
            }
            // Button: I Already Have an Account
            Button(
                onClick = {
                    navController.navigate("screen_auth")
                    
                },
                modifier = Modifier.fillMaxWidth().height(52.dp),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2563EB))
            ) {
                Text("I Already Have an Account", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color.White)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BiometricSignInScreen(navController: NavController) {
    val scrollState = rememberScrollState()
    var inputValue by remember { mutableStateOf("") }
    var toggleState by remember { mutableStateOf(true) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("02. Biometric Sign In", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                },
                actions = {
                    IconButton(onClick = { /* Handle Notifications */ }) {
                        Icon(Icons.Default.Notifications, contentDescription = "Notifications", tint = Color.LightGray)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF0F172A))
            )
        },
        containerColor = Color(0xFF0F172A)
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(scrollState)
                .padding(horizontal = 20.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text("Secure Sign In", color = Color.White)
            // Input: Work Email Address
            OutlinedTextField(
                value = inputValue,
                onValueChange = { inputValue = it },
                label = { Text("Work Email Address") },
                placeholder = { Text("stephen@company.com") },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Color(0xFF2563EB),
                    unfocusedBorderColor = Color(0xFF334155),
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White
                )
            )
            // Input: Master Security Key / Password
            OutlinedTextField(
                value = inputValue,
                onValueChange = { inputValue = it },
                label = { Text("Master Security Key / Password") },
                placeholder = { Text("••••••••••••") },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Color(0xFF2563EB),
                    unfocusedBorderColor = Color(0xFF334155),
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White
                )
            )
            // Switch Toggle
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Enable FaceID Quick Authentication", color = Color.White, fontSize = 14.sp)
                Switch(
                    checked = toggleState,
                    onCheckedChange = { toggleState = it },
                    colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = Color(0xFF2563EB))
                )
            }
            // Button: Sign In to Account
            Button(
                onClick = {
                    navController.navigate("screen_dashboard")
                    
                },
                modifier = Modifier.fillMaxWidth().height(52.dp),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2563EB))
            ) {
                Text("Sign In to Account", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color.White)
            }
            Text("or sign in with identity provider", color = Color.White)
            // Button: Use Hardware Passkey / YubiKey
            Button(
                onClick = {
                    
                    
                },
                modifier = Modifier.fillMaxWidth().height(52.dp),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2563EB))
            ) {
                Text("Use Hardware Passkey / YubiKey", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color.White)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainPortfolioDashboardScreen(navController: NavController) {
    val scrollState = rememberScrollState()
    var inputValue by remember { mutableStateOf("") }
    var toggleState by remember { mutableStateOf(true) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("03. Main Portfolio Dashboard", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                },
                actions = {
                    IconButton(onClick = { /* Handle Notifications */ }) {
                        Icon(Icons.Default.Notifications, contentDescription = "Notifications", tint = Color.LightGray)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF0F172A))
            )
        },
        containerColor = Color(0xFF0F172A)
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(scrollState)
                .padding(horizontal = 20.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text("FinPulse Vault", color = Color.White)
            // Metric Summary
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Total Net Liquid Assets", color = Color.Gray, fontSize = 12.sp)
                    Text("$148,920.45", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                    Text("+12.4% past 30 days", color = Color(0xFF10B981), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
            Text("Special Promotions & High Yield Drops", color = Color.White)
            // Button: Send Instant Transfer
            Button(
                onClick = {
                    navController.navigate("screen_transfer")
                    
                },
                modifier = Modifier.fillMaxWidth().height(52.dp),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2563EB))
            ) {
                Text("Send Instant Transfer", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color.White)
            }
            Text("Stripe SaaS Revenue Payout", color = Color.White)
            Text("Amazon Web Services Cloud Infrastructure", color = Color.White)
            // Card: Earn 5.2% APY on USD Treasury
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B))
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Earn 5.2% APY on USD Treasury", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    Text("Compound daily interest backed by US short-term notes.", color = Color.Gray, fontSize = 12.sp)
                }
            }
            Text("Navigation Bar", color = Color.White)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InstantTransferFormScreen(navController: NavController) {
    val scrollState = rememberScrollState()
    var inputValue by remember { mutableStateOf("") }
    var toggleState by remember { mutableStateOf(true) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("04. Instant Transfer Form", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                },
                actions = {
                    IconButton(onClick = { /* Handle Notifications */ }) {
                        Icon(Icons.Default.Notifications, contentDescription = "Notifications", tint = Color.LightGray)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF0F172A))
            )
        },
        containerColor = Color(0xFF0F172A)
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(scrollState)
                .padding(horizontal = 20.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text("New Transfer", color = Color.White)
            // Input: Recipient Tag or IBAN
            OutlinedTextField(
                value = inputValue,
                onValueChange = { inputValue = it },
                label = { Text("Recipient Tag or IBAN") },
                placeholder = { Text("Search @handle, email, or IBAN") },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Color(0xFF2563EB),
                    unfocusedBorderColor = Color(0xFF334155),
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White
                )
            )
            // Input: Amount in USD ($)
            OutlinedTextField(
                value = inputValue,
                onValueChange = { inputValue = it },
                label = { Text("Amount in USD ($)") },
                placeholder = { Text("0.00") },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Color(0xFF2563EB),
                    unfocusedBorderColor = Color(0xFF334155),
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White
                )
            )
            // Input: Memo / Reference
            OutlinedTextField(
                value = inputValue,
                onValueChange = { inputValue = it },
                label = { Text("Memo / Reference") },
                placeholder = { Text("e.g. Q4 Consulting Retainer") },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Color(0xFF2563EB),
                    unfocusedBorderColor = Color(0xFF334155),
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White
                )
            )
            // Card: Estimated Arrival: Under 30 seconds
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B))
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Estimated Arrival: Under 30 seconds", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    Text("Zero network fees · Live FX rate locked for 15 min.", color = Color.Gray, fontSize = 12.sp)
                }
            }
            // Button: Confirm & Transfer $2,500.00
            Button(
                onClick = {
                    navController.navigate("screen_success")
                    
                },
                modifier = Modifier.fillMaxWidth().height(52.dp),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2563EB))
            ) {
                Text("Confirm & Transfer $2,500.00", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color.White)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TransferCompletedReceiptScreen(navController: NavController) {
    val scrollState = rememberScrollState()
    var inputValue by remember { mutableStateOf("") }
    var toggleState by remember { mutableStateOf(true) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("05. Transfer Completed Receipt", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                },
                actions = {
                    IconButton(onClick = { /* Handle Notifications */ }) {
                        Icon(Icons.Default.Notifications, contentDescription = "Notifications", tint = Color.LightGray)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF0F172A))
            )
        },
        containerColor = Color(0xFF0F172A)
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(scrollState)
                .padding(horizontal = 20.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Badge: INSTANT SETTLEMENT COMPLETED
            Surface(
                color = Color(0xFF10B981).copy(alpha = 0.15f),
                shape = RoundedCornerShape(20.dp)
            ) {
                Text(
                    text = "INSTANT SETTLEMENT COMPLETED",
                    color = Color(0xFF10B981),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                )
            }
            // Metric Summary
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Sent to Elena Rostova", color = Color.Gray, fontSize = 12.sp)
                    Text("$2,500.00 USD", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                    Text("Transaction Hash: #FP-994021", color = Color(0xFF10B981), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
            // Card: Payment Confirmation Sent
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B))
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Payment Confirmation Sent", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    Text("A cryptographic proof of payment has been emailed to both parties and recorded on the ledger.", color = Color.Gray, fontSize = 12.sp)
                }
            }
            // Button: Back to Main Dashboard
            Button(
                onClick = {
                    navController.navigate("screen_dashboard")
                    
                },
                modifier = Modifier.fillMaxWidth().height(52.dp),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2563EB))
            ) {
                Text("Back to Main Dashboard", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color.White)
            }
            // Button: Download PDF Tax Receipt
            Button(
                onClick = {
                    
                    
                },
                modifier = Modifier.fillMaxWidth().height(52.dp),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2563EB))
            ) {
                Text("Download PDF Tax Receipt", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color.White)
            }
        }
    }
}

@Composable
fun FlowCraftAndroidTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Color(0xFF2563EB),
            secondary = Color(0xFF10B981),
            background = Color(0xFF0F172A),
            surface = Color(0xFF1E293B),
            onPrimary = Color.White,
            onSurface = Color.White
        ),
        content = content
    )
}
