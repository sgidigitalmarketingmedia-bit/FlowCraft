# Native Android (Jetpack Compose)
Project: FinPulse Mobile - Banking & Crypto Flow
Target: Android 15 / Pixel 9 Pro & Samsung Galaxy S25
Framework: Jetpack Compose with Material 3 Navigation

### How to Run:
1. Open Android Studio Ladybug or newer.
2. Create an 'Empty Activity' project with Compose.
3. Replace `MainActivity.kt` in `com.flowcraft.mobile.ui`.
4. Sync Gradle and Run on an Android emulator or device.