# FinPulse Mobile - Banking & Crypto Flow

Exported from **FlowCraft Pro** interactive journey builder.

## Quickstart

```bash
npm install
npm run dev
```

Open [http://localhost:5173](http://localhost:5173) in your browser.

## Features
- Complete interactive journey flows with state machine transitions
- Responsive mobile hardware bezel simulator
- Dynamic forms with local validation
- Modular screen components styled with Tailwind CSS
