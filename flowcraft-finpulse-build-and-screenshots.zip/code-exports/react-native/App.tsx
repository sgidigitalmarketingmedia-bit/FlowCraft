/**
 * FlowCraft Pro - React Native & Expo Implementation
 * Project: FinPulse Mobile - Banking & Crypto Flow
 * Platforms: iOS (iPhone 16 Pro), Android (Pixel 9 Pro, Galaxy S25)
 */

import React, { useState } from 'react';
import { 
  StyleSheet, View, Text, TouchableOpacity, TextInput, 
  ScrollView, Switch, SafeAreaView, StatusBar, Alert 
} from 'react-native';

export default function App() {
  const [currentScreen, setCurrentScreen] = useState('screen_splash');
  const [history, setHistory] = useState(['screen_splash']);

  const navigateTo = (screenId: string) => {
    setHistory(prev => [...prev, screenId]);
    setCurrentScreen(screenId);
  };

  const goBack = () => {
    if (history.length > 1) {
      const nextHistory = [...history];
      nextHistory.pop();
      setHistory(nextHistory);
      setCurrentScreen(nextHistory[nextHistory.length - 1]);
    }
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      <StatusBar barStyle="light-content" backgroundColor="#0F172A" />
      <View style={styles.container}>
        {/* Screen Controller */}
        {currentScreen === 'screen_splash' && (
          <ScrollView style={styles.scrollArea} contentContainerStyle={styles.contentContainer}>
            <View style={styles.headerRow}>
              
              <Text style={styles.screenTitle}>00. Motion Launch Splash</Text>
            </View>
            <View style={styles.elementWrapper}>
              
              <Text style={styles.genericText}>FlowCraft Pro Launch Screen</Text>
            </View>
          </ScrollView>
        )}
        {currentScreen === 'screen_onboarding' && (
          <ScrollView style={styles.scrollArea} contentContainerStyle={styles.contentContainer}>
            <View style={styles.headerRow}>
              <TouchableOpacity onPress={goBack} style={styles.backBtn}>
                <Text style={styles.backText}>‹ Back</Text>
              </TouchableOpacity>
              <Text style={styles.screenTitle}>01. Welcome Onboarding</Text>
            </View>
            <View style={styles.elementWrapper}>
              
              <Text style={styles.genericText}>FinPulse Mobile</Text>
            </View>
            <View style={styles.elementWrapper}>
              
              <View style={styles.card}>
                <Text style={styles.cardTitle}>Zero Fee Global Transfers</Text>
                <Text style={styles.cardDesc}>Manage 42 fiat currencies and digital assets in one high-security mobile vault.</Text>
              </View>
            </View>
            <View style={styles.elementWrapper}>
              
              <Text style={styles.genericText}>Platform Architecture Walkthrough</Text>
            </View>
            <View style={styles.elementWrapper}>
              
              <Text style={styles.genericText}>SOC-2 Type II Verified & Bank-Grade Encrypted</Text>
            </View>
            <View style={styles.elementWrapper}>
              
              <TouchableOpacity 
                style={[styles.primaryButton, {}]}
                onPress={() => {
                  navigateTo('screen_auth');
                  
                  
                }}
              >
                <Text style={styles.buttonText}>Get Started Now</Text>
              </TouchableOpacity>
            </View>
            <View style={styles.elementWrapper}>
              
              <TouchableOpacity 
                style={[styles.primaryButton, {}]}
                onPress={() => {
                  navigateTo('screen_auth');
                  
                  
                }}
              >
                <Text style={styles.buttonText}>I Already Have an Account</Text>
              </TouchableOpacity>
            </View>
          </ScrollView>
        )}
        {currentScreen === 'screen_auth' && (
          <ScrollView style={styles.scrollArea} contentContainerStyle={styles.contentContainer}>
            <View style={styles.headerRow}>
              <TouchableOpacity onPress={goBack} style={styles.backBtn}>
                <Text style={styles.backText}>‹ Back</Text>
              </TouchableOpacity>
              <Text style={styles.screenTitle}>02. Biometric Sign In</Text>
            </View>
            <View style={styles.elementWrapper}>
              
              <Text style={styles.genericText}>Secure Sign In</Text>
            </View>
            <View style={styles.elementWrapper}>
              
              <Text style={styles.genericText}>Work Email Address</Text>
            </View>
            <View style={styles.elementWrapper}>
              
              <Text style={styles.genericText}>Master Security Key / Password</Text>
            </View>
            <View style={styles.elementWrapper}>
              
              <Text style={styles.genericText}>Enable FaceID Quick Authentication</Text>
            </View>
            <View style={styles.elementWrapper}>
              
              <TouchableOpacity 
                style={[styles.primaryButton, {}]}
                onPress={() => {
                  navigateTo('screen_dashboard');
                  
                  
                }}
              >
                <Text style={styles.buttonText}>Sign In to Account</Text>
              </TouchableOpacity>
            </View>
            <View style={styles.elementWrapper}>
              
              <Text style={styles.genericText}>or sign in with identity provider</Text>
            </View>
            <View style={styles.elementWrapper}>
              
              <TouchableOpacity 
                style={[styles.primaryButton, {}]}
                onPress={() => {
                  
                  
                  Alert.alert('Notice', 'Passkey verification simulated successfully!');
                }}
              >
                <Text style={styles.buttonText}>Use Hardware Passkey / YubiKey</Text>
              </TouchableOpacity>
            </View>
          </ScrollView>
        )}
        {currentScreen === 'screen_dashboard' && (
          <ScrollView style={styles.scrollArea} contentContainerStyle={styles.contentContainer}>
            <View style={styles.headerRow}>
              <TouchableOpacity onPress={goBack} style={styles.backBtn}>
                <Text style={styles.backText}>‹ Back</Text>
              </TouchableOpacity>
              <Text style={styles.screenTitle}>03. Main Portfolio Dashboard</Text>
            </View>
            <View style={styles.elementWrapper}>
              
              <Text style={styles.genericText}>FinPulse Vault</Text>
            </View>
            <View style={styles.elementWrapper}>
              
              <View style={styles.metricCard}>
                <Text style={styles.metricLabel}>Total Net Liquid Assets</Text>
                <Text style={styles.metricValue}>$148,920.45</Text>
                <Text style={styles.metricChange}>+12.4% past 30 days</Text>
              </View>
            </View>
            <View style={styles.elementWrapper}>
              
              <Text style={styles.genericText}>Special Promotions & High Yield Drops</Text>
            </View>
            <View style={styles.elementWrapper}>
              
              <TouchableOpacity 
                style={[styles.primaryButton, {}]}
                onPress={() => {
                  navigateTo('screen_transfer');
                  
                  
                }}
              >
                <Text style={styles.buttonText}>Send Instant Transfer</Text>
              </TouchableOpacity>
            </View>
            <View style={styles.elementWrapper}>
              
              <Text style={styles.genericText}>Stripe SaaS Revenue Payout</Text>
            </View>
            <View style={styles.elementWrapper}>
              
              <Text style={styles.genericText}>Amazon Web Services Cloud Infrastructure</Text>
            </View>
            <View style={styles.elementWrapper}>
              
              <View style={styles.card}>
                <Text style={styles.cardTitle}>Earn 5.2% APY on USD Treasury</Text>
                <Text style={styles.cardDesc}>Compound daily interest backed by US short-term notes.</Text>
              </View>
            </View>
            <View style={styles.elementWrapper}>
              
              <Text style={styles.genericText}>Navigation Bar</Text>
            </View>
          </ScrollView>
        )}
        {currentScreen === 'screen_transfer' && (
          <ScrollView style={styles.scrollArea} contentContainerStyle={styles.contentContainer}>
            <View style={styles.headerRow}>
              <TouchableOpacity onPress={goBack} style={styles.backBtn}>
                <Text style={styles.backText}>‹ Back</Text>
              </TouchableOpacity>
              <Text style={styles.screenTitle}>04. Instant Transfer Form</Text>
            </View>
            <View style={styles.elementWrapper}>
              
              <Text style={styles.genericText}>New Transfer</Text>
            </View>
            <View style={styles.elementWrapper}>
              
              <Text style={styles.genericText}>Recipient Tag or IBAN</Text>
            </View>
            <View style={styles.elementWrapper}>
              
              <Text style={styles.genericText}>Amount in USD ($)</Text>
            </View>
            <View style={styles.elementWrapper}>
              
              <Text style={styles.genericText}>Memo / Reference</Text>
            </View>
            <View style={styles.elementWrapper}>
              
              <View style={styles.card}>
                <Text style={styles.cardTitle}>Estimated Arrival: Under 30 seconds</Text>
                <Text style={styles.cardDesc}>Zero network fees · Live FX rate locked for 15 min.</Text>
              </View>
            </View>
            <View style={styles.elementWrapper}>
              
              <TouchableOpacity 
                style={[styles.primaryButton, {}]}
                onPress={() => {
                  navigateTo('screen_success');
                  
                  
                }}
              >
                <Text style={styles.buttonText}>Confirm & Transfer $2,500.00</Text>
              </TouchableOpacity>
            </View>
          </ScrollView>
        )}
        {currentScreen === 'screen_success' && (
          <ScrollView style={styles.scrollArea} contentContainerStyle={styles.contentContainer}>
            <View style={styles.headerRow}>
              <TouchableOpacity onPress={goBack} style={styles.backBtn}>
                <Text style={styles.backText}>‹ Back</Text>
              </TouchableOpacity>
              <Text style={styles.screenTitle}>05. Transfer Completed Receipt</Text>
            </View>
            <View style={styles.elementWrapper}>
              
              <Text style={styles.genericText}>INSTANT SETTLEMENT COMPLETED</Text>
            </View>
            <View style={styles.elementWrapper}>
              
              <View style={styles.metricCard}>
                <Text style={styles.metricLabel}>Sent to Elena Rostova</Text>
                <Text style={styles.metricValue}>$2,500.00 USD</Text>
                <Text style={styles.metricChange}>Transaction Hash: #FP-994021</Text>
              </View>
            </View>
            <View style={styles.elementWrapper}>
              
              <View style={styles.card}>
                <Text style={styles.cardTitle}>Payment Confirmation Sent</Text>
                <Text style={styles.cardDesc}>A cryptographic proof of payment has been emailed to both parties and recorded on the ledger.</Text>
              </View>
            </View>
            <View style={styles.elementWrapper}>
              
              <TouchableOpacity 
                style={[styles.primaryButton, {}]}
                onPress={() => {
                  navigateTo('screen_dashboard');
                  
                  
                }}
              >
                <Text style={styles.buttonText}>Back to Main Dashboard</Text>
              </TouchableOpacity>
            </View>
            <View style={styles.elementWrapper}>
              
              <TouchableOpacity 
                style={[styles.primaryButton, {}]}
                onPress={() => {
                  
                  
                  Alert.alert('Notice', 'PDF Receipt downloaded to your device.');
                }}
              >
                <Text style={styles.buttonText}>Download PDF Tax Receipt</Text>
              </TouchableOpacity>
            </View>
          </ScrollView>
        )}
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: '#0F172A',
  },
  container: {
    flex: 1,
    backgroundColor: '#0F172A',
  },
  scrollArea: {
    flex: 1,
  },
  contentContainer: {
    padding: 20,
    gap: 14,
  },
  headerRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  backBtn: {
    marginRight: 10,
    paddingVertical: 6,
    paddingHorizontal: 10,
    backgroundColor: '#1E293B',
    borderRadius: 8,
  },
  backText: {
    color: '#60A5FA',
    fontWeight: 'bold',
  },
  screenTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#FFFFFF',
  },
  elementWrapper: {
    width: '100%',
  },
  primaryButton: {
    backgroundColor: '#2563EB',
    paddingVertical: 14,
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: '#2563EB',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 6,
    elevation: 4,
  },
  secondaryBtn: {
    backgroundColor: '#334155',
  },
  buttonText: {
    color: '#FFFFFF',
    fontWeight: 'bold',
    fontSize: 15,
  },
  card: {
    backgroundColor: '#1E293B',
    padding: 16,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.08)',
  },
  cardTitle: {
    fontSize: 15,
    fontWeight: '600',
    color: '#FFFFFF',
    marginBottom: 4,
  },
  cardDesc: {
    fontSize: 12,
    color: '#94A3B8',
  },
  metricCard: {
    backgroundColor: '#1E293B',
    padding: 16,
    borderRadius: 16,
  },
  metricLabel: {
    fontSize: 12,
    color: '#94A3B8',
  },
  metricValue: {
    fontSize: 26,
    fontWeight: 'bold',
    color: '#FFFFFF',
    marginVertical: 4,
  },
  metricChange: {
    fontSize: 12,
    color: '#10B981',
    fontWeight: 'bold',
  },
  genericText: {
    color: '#E2E8F0',
    fontSize: 14,
  },
});
