# High-Resolution Product Screenshots Catalog
Project: FinPulse Mobile - Banking & Crypto Flow
Generated: 2026-10-14T14:22:15.171Z

### Included High-Resolution Screenshots:
1. **00-motion-splash-screen.png** (750x1520):
   - Dynamic motion splash launch screen with brand glowing logo, pulse rings, and 2.8s dwell auto-advance timer.
2. **01-welcome-onboarding-screen.png** (750x1520):
   - Welcome onboarding screen featuring the hero visual banner, zero-fee global transfers card, interactive internet video player walkthrough with play controls, SOC-2 verified badge, primary CTA buttons, and Lead Architect API specification note.
3. **02-biometric-authentication-screen.png** (750x1520):
   - Biometric sign-in artboard with email/password input fields, active FaceID quick authentication toggle, hardware passkey/YubiKey button, and fallback security protocol note.
4. **03-portfolio-dashboard-screen.png** (750x1520):
   - Wealth & cash portfolio dashboard displaying total balance ($148,920.45, +12.4%), interactive featured promotions carousel with active slides and hyperlink triggers, instant transfer action, recent transactions (Stripe, AWS), and bottom tab bar dock.
5. **04-instant-transfer-screen.png** (750x1520):
   - Instant transfer form with recipient IBAN/tag, live balance check, numeric amount field ($2,500.00), payment reference note, and 30-second arrival guarantee card.
6. **05-transfer-receipt-success.png** (750x1520):
   - Transfer completed settlement receipt featuring green verified badge, settlement proof hash (#FP-994021), network breakdown, and actions to return or download PDF receipt.
7. **06-full-canvas-workspace-overview.png** (1920x1080):
   - Panoramic canvas workspace displaying all 6 mobile artboards in sequence, connected with visual bezier navigation flow wires, screen labels, component library sidebar, and top studio navigation.
8. **07-properties-panel-and-cms-inspector.png** (1920x1080):
   - Deep-dive inspector view showing the video URL input, local/internet source selector, CMS graphic assets browser, carousel timing sliders, and multi-platform export panel.